﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam2
{
   public  class Student
    {
        public string StuName { get; set; }
    }
}
